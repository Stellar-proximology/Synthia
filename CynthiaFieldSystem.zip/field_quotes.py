"""
Field Quote Selector for Cynthia AI
Pulls Kemetic quotes by consciousness field for daily or situational use.
"""

import random

field_quotes = {
    "Mind": [
        "Speech is braver than battle",
        "Fill yourself with silence and you will find life",
        "The tongue is the steering oar, God is the pilot"
    ],
    "Heart": [
        "Do justice, that you may live long",
        "Feed others from your own bread",
        "Instill your love into the world"
    ],
    "Body": [
        "Maintain your altar and temple",
        "Do not destroy ancient buildings",
        "Activity produces riches"
    ],
    "Shadow": [
        "The greedy person will come to no good",
        "Do not make secret deals with grain measurers",
        "Do not falsify or deceive, even in survival"
    ],
    "Child": [
        "Seize the day as it passes",
        "Spend your days joyfully and do not be weary with living",
        "Let your heart be drunk on the gift of Day"
    ],
    "Will": [
        "Make your influential leaders great",
        "Speak truth in your house",
        "Be clear in leadership"
    ],
    "Soul": [
        "The soul goes where it knows",
        "Beautify your mansion in the West",
        "Provide for the people — the cattle of God"
    ],
    "Spirit": [
        "God is ineffable spirit",
        "God cures without ointments",
        "Justice shall rise to her throne"
    ],
    "Synthesis": [
        "Justice is forever",
        "Existence yonder is eternal",
        "God’s word perpetuates or destroys"
    ],

}

def get_quote(field):
    """Return a random quote for the given field"""
    return random.choice(field_quotes.get(field, ["No quote available."]))

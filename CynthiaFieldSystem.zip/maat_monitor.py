"""
Ma’at Monitor - Simple behavior log checker
Flags when user logs or journal entries may indicate field distortion or alignment
"""

def check_for_distortion(text, trigger_map):
    flagged_fields = []
    text_lower = text.lower()
    for field, triggers in trigger_map.items():
        for word in triggers:
            if word in text_lower:
                flagged_fields.append(field)
                break
    return flagged_fields

trigger_keywords = {
    "Mind": ["reactive", "impulsive", "speech", "debate", "misunderstood"],
    "Heart": ["hurt", "grief", "justice", "compassion", "betrayal"],
    "Body": ["tired", "overwhelmed", "lazy", "structure", "habit"],
    "Shadow": ["lie", "cheat", "distort", "greed", "manipulate"],
    "Child": ["joy", "tired", "wonder", "play", "creative block"],
    "Will": ["leadership", "decide", "weak", "uncertain", "responsibility"],
    "Soul": ["legacy", "ancestor", "regret", "soul", "forgotten"],
    "Spirit": ["faith", "hope", "guidance", "unknown", "divine"],
    "Synthesis": ["unity", "purpose", "law", "balance", "fate"],

}

# FastAPI Backend Template for Synthia Platform
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uvicorn

app = FastAPI(
    title="Synthia Consciousness Platform API",
    description="Backend API for consciousness field management",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class FieldState(BaseModel):
    name: str
    energy: float
    distortion: float
    alignment: float
    active_quests: List[str]

@app.get("/api/fields", response_model=List[FieldState])
async def get_all_fields():
    return [
        FieldState(name="Mind", energy=85.0, distortion=5.0, alignment=75.0, active_quests=["Refine Pattern"]),
        FieldState(name="Heart", energy=92.0, distortion=3.0, alignment=88.0, active_quests=["Open Connection"])
    ]

@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "service": "Synthia API"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
